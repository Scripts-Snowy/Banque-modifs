Config = {}
Config.DrawDistance = 15
Config.Size         = {x = 0.8, y = 1.0, z = 0.5}
Config.Color        = {r = 0, g = 255, b = 0}
Config.Type         = 2